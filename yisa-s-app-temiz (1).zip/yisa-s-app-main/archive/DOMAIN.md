# Patron paneli domain

Bu proje **app.yisa-s.com** üzerinden yayınlanacak.

- Vercel'de bu repo'ya **app.yisa-s.com** domain'ini ekleyin (Settings > Domains).
- Gerekirse: `NEXT_PUBLIC_SITE_URL=https://app.yisa-s.com`

Tanıtım sitesi (yisa-s.com) ayrı projedir: `YISA_S_SITE_KOMPLE\yisa-s-site`.
