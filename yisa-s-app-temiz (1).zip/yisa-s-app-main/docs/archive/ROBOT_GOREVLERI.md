# app.yisa-s.com — Robot / API Görevleri

**Domain:** app.yisa-s.com  
**Merkez rehber:** `C:\Users\info\YISA-S_KURULUM_DEPLOY_VE_ROBOT_GOREVLERI.md`

| Endpoint | Metod | Görevi |
|----------|-------|--------|
| `/api/chat` | POST | **Patron asistanı** — Dashboard sohbeti, Claude “YİSA-S Patron Asistanı” |

Giriş: `/` | Dashboard: `/dashboard` — Robot sohbeti dashboard içinde, `/api/chat` kullanır.
