# YİSA-S — Yönetici İşletmeci Sporcu Antrenör Sistemi

AI robotlarla yönetilen spor tesisi franchise platformu.

## Hızlı Başlangıç

```bash
npm install
cp .env.example .env.local   # API key'leri doldurun
npm run dev                   # http://localhost:3000
```

## Yapı

| Klasör | İçerik |
|--------|--------|
| `app/` | Next.js App Router sayfaları |
| `lib/robots/` | Robot hiyerarşisi ve CELF direktörlükleri |
| `lib/patron-robot/` | Orkestratör + AI agent'ları |
| `lib/auth/` | Kimlik doğrulama ve roller |
| `lib/db/` | Veritabanı işlemleri |
| `components/` | UI bileşenleri |
| `supabase/` | Migration ve SQL dosyaları |
| `docs/` | Tüm dökümanlar |

## Paneller

| Panel | URL | Açıklama |
|-------|-----|----------|
| Landing | yisa-s.com | Tanıtım sayfası |
| Patron | app.yisa-s.com | Komuta merkezi |
| Franchise | franchise.yisa-s.com | Tesis yönetimi |
| Veli | veli.yisa-s.com | Veli takip paneli |

## Gerekli ENV

```
NEXT_PUBLIC_SUPABASE_URL=
NEXT_PUBLIC_SUPABASE_ANON_KEY=
SUPABASE_SERVICE_ROLE_KEY=
OPENAI_API_KEY=
ANTHROPIC_API_KEY=
GEMINI_API_KEY=
```

## Lisans

Tescilli yazılım — Tüm hakları saklıdır.
